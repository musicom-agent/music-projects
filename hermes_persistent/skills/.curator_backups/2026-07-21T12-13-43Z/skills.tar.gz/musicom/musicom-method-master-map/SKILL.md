---
name: musicom-method-master-map
type: Method Map
title: Musicom Method Master Map
description: Canonical index of stochastic, rules-based, and nature-led algorithmic music composition methods.
resource: https://github.com/axelwiertz/musicom
tags: [music, algorithms, methods, master-map, okf]
timestamp: 2026-07-15T20:45:00Z
---

# Musicom Method Master Map (OKF)

Every algorithmic composition method used inside the Musicom framework must map to one of three core paradigms:

## 1. Stochastic (Probabilistic)
*   **002 Markov Transitions:** Generates probabilistic harmonic/melodic paths based on state weights.
*   **023 Tendency Masking:** Generates pitch clouds bounded by moving corridors $L(t)$ and $U(t)$.

## 2. Rules-Based (Deterministic)
*   **001 Skeleton-First:** Forms structural grids from DNA pitch and rhythm seeds.
*   **011 Euclidean Groove:** Evaluates rhythmic cycles using pulse and hit counts.
*   **025 Xenakis Sieve:** Generates scales/grids using modular congruence formulas.
*   **032 Isorhythmic Talea-Color Mapping (ITCM):** Decouples rhythmic loop (talea) and pitch loop (color) of coprime lengths to generate non-repeating shifting melodic motifs.

## 3. Nature-Led (Physical/Emergent)
*   **026 DPSM (Phase-Shift Minimalism):** Emerges dynamic polyrhythms via misaligned phase offsets.
*   **030 Reaction-Diffusion Turing Patterns (RDTP):** Generates musical structures and textures from localized chemical concentrations evolving over a 2D reaction-diffusion grid (Gray-Scott model).
*   **031 Swarm Intelligence Flocking (Boids):** Simulates Reynolds' flocking algorithm (separation, alignment, cohesion) to guide multiple autonomous musical agents in a multi-dimensional pitch-time-velocity space.

---

## Technical Pitfall: MIDI Tail Truncation
When compiling cells, short active phrases stop playing before the global track boundary, causing DAW timeline drift on export.
*   **Fix:** Append an absolute silent padding event (`pitch=0, volume=0`) at `total_section_ticks - 1` to ensure perfect track-length symmetry across all rows.
