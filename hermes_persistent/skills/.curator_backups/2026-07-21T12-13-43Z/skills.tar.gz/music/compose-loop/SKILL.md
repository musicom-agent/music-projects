---
name: compose-loop
description: "Rapid 4/8/16-bar loop composition using the musicom UnitMatrix engine. Zero-drift guaranteed."
version: 2.0.0
author: Axel Wiertz
license: MIT
platforms: [linux]
prerequisites:
  env_vars: []
  commands: [/opt/data/micromamba/envs/musicom/bin/python, /opt/data/micromamba/envs/musicom/bin/fluidsynth, ffmpeg]
dependencies: []
metadata:
  hermes:
    tags: [music, composition, generative, MIDI, musicom, loop, zero-drift]
    related_skills: [musicom-theory-kb, music-companion-role-spec, musicom-missing-link-plan]
triggers:
  - compose loop
  - generate loop
  - 4-bar pattern
  - 8-bar pattern
  - 16-bar pattern
  - rapid composition
  - music loop
---

# Compose Loop — Rapid Pattern-Centric Composition (v2)

## CRITICAL: use the musicom engine, never raw mido

The musicom package is installed editable. Imports resolve from any cwd.
Do NOT use `sys.path.insert(...)`, do NOT construct `mido.MidiTrack()` manually.

**Python env:** `/opt/data/micromamba/envs/musicom/bin/python`

### Required imports

```python
from structures import MusicUnit, MusicEvent, UnitMatrix, MidiInstrument, MidiPercussion
from workflows.unitmatrix_composer import (
    UnitMatrixComposer, create_note_unit, create_chord_unit, create_empty_unit,
)
from ai.utils.visualizer import write_grid_visualization
from workflows.provenance import write_provenance, AI_ASSISTED
```

### The only sanctioned workflow

```python
composer = UnitMatrixComposer(bpm=BPM, ticks_per_beat=480, beats_per_bar=4)
composer.create_matrix(num_voices=N, num_sections=M)
composer.add_voice("Lead", program=MidiInstrument.FLUTE, channel=0)
composer.add_voice("Drums", program=0, channel=9)  # percussion channel
composer.add_section("A", bars=4)
composer.fill_voice_section("Lead", "A", melody_unit)
composer.fill_voice_section("Drums", "A", drum_unit)
ok, msg = composer.validate()     # MUST be True — zero-drift gate
composer.to_midi(out_path)
```

**Order:** `create_matrix → add_voice → add_section → fill_voice_section → validate → to_midi`.

## Building MusicUnits

```python
# From explicit events (absolute ticks)
BAR = 480 * 4   # 1 bar at 480 tpb, 4/4
melody = MusicUnit(events=[
    MusicEvent(pitch=60, volume=90, start_tick=0, end_tick=480),
    MusicEvent(pitch=62, volume=90, start_tick=480, end_tick=960),
    ...
])

# From generators
from generators.stochastic import StochasticGenerator
from generators.schillinger import SchillingerGenerator
from generators.tendency_masking import TendencyMaskingGenerator
from generators.markov import MarkovGenerator
```

### Unit operations (in-place)
```python
melody.transpose(12)    # up octave
melody.retrograde()     # reverse
melody.invert(60)       # mirror around C4
melody.augment(2.0)     # stretch durations x2
```

## Rendering MIDI → Audio

```bash
PY=/opt/data/micromamba/envs/musicom/bin
$PY/fluidsynth -ni -g 1.2 -F out.wav TimGM6mb.sf2 out.mid
ffmpeg -y -i out.wav out.ogg
```

**FluidSynth IS installed.** Gain `-g 1.2` prevents decay tail truncation.

## Output location & structure (hard rule)

- **Research experiments** → `/opt/data/projects/Research/outputs/<project>/`
- **Style compositions** → `/opt/data/projects/Styles/<Style>/<project>/` (MIDI/, Audio/, etc. in-project)

```
<project>/
├── <name>.mid
├── <name>.wav / .ogg
├── grid_visualization.txt
├── <name>.mid.provenance.json
└── README.md (optional)
```

## Verify-don't-trust (mandatory)

```python
import os
assert os.path.getsize(midi_path) > 40, "empty/corrupt — regenerate"
```

## Visualize before trusting

```python
from ai.utils.visualizer import write_grid_visualization
write_grid_visualization(composer.matrix, f"{out_dir}/grid_visualization.txt",
                         ticks_per_character=240, voice_names=["Lead","Bass"], bpm=BPM)
```

## Provenance sidecar

```python
from workflows.provenance import write_provenance, AI_ASSISTED
write_provenance(midi_path, AI_ASSISTED, "compose-loop/<project>",
                 parameters={"bpm": BPM, "key": "C major"})
```

## Run preflight before finishing

```bash
/opt/data/micromamba/envs/musicom/bin/python \
  /opt/data/projects/Research/preflight_check.py <your_project_dir>
```

Exit 0 = compliant. Non-zero = fix violations.

## Starter template

Copy `/opt/data/projects/Research/_TEMPLATE/` for a ready-to-fill scaffold.

## When NOT to use

- Full songs with vocals → use `songwriting-and-ai-music`
- Complex orchestral scores → use the same engine with more voices/sections
- Analysis-only tasks → `mido` import for reading is fine (not authoring)

## Pitfalls (verified)

- `MusicUnit` has NO `append()` — use `add_event(MusicEvent(...))`
- Percussion = channel 9, program 0. Use `MidiPercussion.BASS_DRUM` etc.
- `MusicEvent.duration` = `end_tick - start_tick` (fixed; works at start_tick=0 now)
- All rows in UnitMatrix MUST have equal total length — `validate()` catches drift
- Avoid `UnitMatrix(voices=4, sections=1)` — use `UnitMatrix(shape=(4, 1))`
- `MusicPitchClassSet` construction currently broken (pitchclass.py:301 stub bug) — avoid for now; use explicit pitch lists instead
