#!/usr/bin/env python3
import imaplib
import os
import email
from email.header import decode_header
import datetime
import html.parser
import re

class HTMLStripper(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.reset()
        self.convert_charrefs = True
        self.text = []
    def handle_data(self, d):
        self.text.append(d)
    def get_data(self):
        return ''.join(self.text)

def strip_tags(html_content):
    s = HTMLStripper()
    s.feed(html_content)
    return s.get_data()

def decode_str(s):
    if s is None:
        return ''
    parts = decode_header(s)
    out = []
    for part, charset in parts:
        if isinstance(part, bytes):
            out.append(part.decode(charset or 'utf-8', errors='replace'))
        else:
            out.append(str(part))
    return ''.join(out)

def get_body(msg):
    body_parts = []
    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            cd = str(part.get("Content-Disposition"))
            if ct == 'text/plain' and "attachment" not in cd:
                payload = part.get_payload(decode=True)
                if payload:
                    body_parts.append(payload.decode('utf-8', errors='replace'))
                    break
        if not body_parts:
            for part in msg.walk():
                ct = part.get_content_type()
                cd = str(part.get("Content-Disposition"))
                if ct == 'text/html' and "attachment" not in cd:
                    payload = part.get_payload(decode=True)
                    if payload:
                        html_text = payload.decode('utf-8', errors='replace')
                        body_parts.append(strip_tags(html_text))
                        break
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            ct = msg.get_content_type()
            if ct == 'text/html':
                body_parts.append(strip_tags(payload.decode('utf-8', errors='replace')))
            else:
                body_parts.append(payload.decode('utf-8', errors='replace'))
    
    text = '\n'.join(body_parts)
    text = re.sub(r'\n\s*\n', '\n\n', text)
    return text.strip()

def main():
    possible_paths = ['./.env.mail', '/opt/data/.env.mail', os.path.expanduser('~/.env.mail')]
    env_path = None
    for p in possible_paths:
        if os.path.exists(p):
            env_path = p
            break
            
    creds = {}
    if env_path:
        with open(env_path, 'r') as f:
            for line in f:
                if '=' in line and not line.startswith('#'):
                    k, v = line.strip().split('=', 1)
                    creds[k] = v

    imap_server = creds.get('IMAP_HOST', 'imap.infomaniak.com')
    imap_port = int(creds.get('IMAP_PORT', 993))
    imap_user = creds.get('IMAP_USER', 'musicom@wiertz.tech')
    imap_pass = creds.get('IMAP_PASS', '2a+hQO+xf9T9%Uf3')

    try:
        mail = imaplib.IMAP4_SSL(imap_server, imap_port)
        mail.login(imap_user, imap_pass)
        mail.select('INBOX', readonly=True)
        
        date_since = (datetime.date.today() - datetime.timedelta(days=7)).strftime("%d-%b-%Y")
        status, data = mail.search(None, f'SINCE {date_since}')
        
        ids = data[0].split() if (status == 'OK' and data[0]) else []
        
        if not ids:
            status, data = mail.search(None, 'ALL')
            all_ids = data[0].split() if (status == 'OK' and data[0]) else []
            ids = all_ids[-15:]
            
        print(f"### FETCHED {len(ids)} RECENT EMAILS ###\n")
        
        for idx, mid in enumerate(reversed(ids), 1):
            status, msg_data = mail.fetch(mid, '(RFC822)')
            if status != 'OK':
                continue
            msg = email.message_from_bytes(msg_data[0][1])
            subject = decode_str(msg.get('Subject', ''))
            from_addr = decode_str(msg.get('From', ''))
            date_str = decode_str(msg.get('Date', ''))
            
            list_unsub = msg.get('List-Unsubscribe', '')
            is_newsletter = "Yes" if list_unsub or "unsubscribe" in subject.lower() or "newsletter" in subject.lower() else "Unknown"
            
            body = get_body(msg)
            truncated_body = body[:4000] + ("\n...[TRUNCATED]..." if len(body) > 4000 else "")
            
            print(f"--- EMAIL #{idx} ---")
            print(f"From: {from_addr}")
            print(f"Subject: {subject}")
            print(f"Date: {date_str}")
            print(f"Newsletter: {is_newsletter}")
            print(f"Content:")
            print(truncated_body)
            print("-" * 40 + "\n")
            
        mail.logout()
    except Exception as e:
        print(f"ERROR fetching emails: {e}")

if __name__ == '__main__':
    main()
