#!/usr/bin/env bash
# Musicom agent/codebase state probe. Evidence-first: run before any SWOT.
# Usage: bash verify_state.sh [REPO] [PY]
set -uo pipefail
REPO="${1:-/opt/data/repos/musicom}"
PY="${2:-/opt/data/micromamba/envs/musicom/bin/python}"
cd "$REPO" || { echo "NO REPO $REPO"; exit 1; }

echo "=== 1. import shell ==="
"$PY" -c "import musicom; print('import OK; path=', musicom.__file__, '; pkgpath=', list(getattr(musicom,'__path__',[]) or []))" 2>&1

echo "=== 2. real export (expect FAIL if namespace-only) ==="
"$PY" -c "from musicom import UnitMatrix, MusicUnit, MusicEvent; print('exports OK')" 2>&1 | tail -3

echo "=== 3. submodule / composer ==="
"$PY" -c "from workflows.unitmatrix_composer import UnitMatrixComposer; print('composer OK (flat layout)')" 2>&1 | tail -3

echo "=== 4. installed? ==="
"$PY" -m pip show musicom 2>&1 | head -3

echo "=== 5. tests ==="
"$PY" -m pytest tests/ -q 2>&1 | tail -8

echo "=== 6. git ==="
git status -s 2>/dev/null | head -25
echo "--- recent commits ---"
git log --oneline -5 2>/dev/null

echo "=== 7. example import style (reveals path hacks / layout) ==="
grep -RhoE "^(import|from) [A-Za-z_.]+" examples/ 2>/dev/null | sort | uniq -c | sort -rn | head -20

echo "=== 8. render outputs (MIDI+WAV+OGG triplets) ==="
ls -1 /opt/data/projects/Research/outputs 2>/dev/null | head -30

echo "=== 9. ecosystem repos ==="
ls -1 "$(dirname "$REPO")" 2>/dev/null
