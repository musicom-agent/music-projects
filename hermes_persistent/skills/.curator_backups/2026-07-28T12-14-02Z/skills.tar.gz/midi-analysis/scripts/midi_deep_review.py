#!/usr/bin/env python3
"""Deep MIDI review helper.

Usage:
  /usr/bin/python3 scripts/midi_deep_review.py /path/to/file.mid

Requires: mido
Prints file structure, tempo/time/key maps, per-track ranges, per-section marker stats,
chromatic-load estimates against declared key, density windows, and large simultaneous attacks.
"""
import sys
import mido
from collections import defaultdict, Counter

NOTE = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B']
MAJOR_PCS = {
    'C': {0,2,4,5,7,9,11}, 'G': {7,9,11,0,2,4,6}, 'D': {2,4,6,7,9,11,1},
    'A': {9,11,1,2,4,6,8}, 'E': {4,6,8,9,11,1,3}, 'B': {11,1,3,4,6,8,10},
    'F#': {6,8,10,11,1,3,5}, 'C#': {1,3,5,6,8,10,0}, 'F': {5,7,9,10,0,2,4},
    'Bb': {10,0,2,3,5,7,9}, 'Eb': {3,5,7,8,10,0,2}, 'Ab': {8,10,0,1,3,5,7},
}

def nn(n):
    return f"{NOTE[n % 12]}{n // 12 - 1}"

def normalize_key(k):
    return str(k).replace('♭', 'b').replace('♯', '#').replace(' major', '').strip()

def main(path):
    mid = mido.MidiFile(path)
    tpb = mid.ticks_per_beat
    tempos, ts, keys, markers, programs = [], [(0,4,4)], [], [], []
    notes = []
    track_infos = []

    for ti, tr in enumerate(mid.tracks):
        at = 0
        active = defaultdict(list)
        name = ''
        counts = Counter()
        for msg in tr:
            at += msg.time
            counts[msg.type] += 1
            if msg.type == 'track_name':
                name = msg.name
            elif msg.type == 'set_tempo':
                tempos.append((at, msg.tempo, mido.tempo2bpm(msg.tempo)))
            elif msg.type == 'time_signature':
                ts.append((at, msg.numerator, msg.denominator))
            elif msg.type == 'key_signature':
                keys.append((ti, at, msg.key))
            elif msg.type == 'marker':
                markers.append((at, msg.text))
            elif msg.type == 'program_change':
                programs.append((ti, at, msg.channel, msg.program))
            elif msg.type == 'note_on' and msg.velocity > 0:
                active[(msg.channel, msg.note)].append((at, msg.velocity))
            elif msg.type in ('note_off', 'note_on'):
                ch = getattr(msg, 'channel', None)
                note = getattr(msg, 'note', None)
                if ch is not None and note is not None and active[(ch, note)]:
                    st, vel = active[(ch, note)].pop(0)
                    notes.append({'start': st, 'end': at, 'dur': at-st, 'track': ti, 'track_name': name,
                                  'ch': ch, 'note': note, 'vel': vel})
        track_infos.append((ti, name, len(tr), counts))

    tempos.sort(); ts = sorted(set(ts)); markers.sort()
    max_tick = max((n['end'] for n in notes), default=0)

    def tick_to_sec(t):
        sec, last, tempo = 0.0, 0, 500000
        for tk, tmp, _ in tempos:
            if tk > t: break
            sec += (tk-last) * tempo / 1_000_000 / tpb
            last, tempo = tk, tmp
        sec += (t-last) * tempo / 1_000_000 / tpb
        return sec

    def bar_of(tick):
        changes = ts
        if changes and changes[0][0] == 0:
            num, den, ci = changes[0][1], changes[0][2], 1
        else:
            num, den, ci = 4, 4, 0
        t, bar = 0, 1
        while t <= tick:
            blen = int(tpb * 4 * num / den)
            next_change = changes[ci][0] if ci < len(changes) else None
            if next_change is not None and t < next_change < t + blen:
                t = next_change; num, den = changes[ci][1], changes[ci][2]; ci += 1
            else:
                if tick < t + blen: return bar
                t += blen; bar += 1
                while ci < len(changes) and changes[ci][0] <= t:
                    num, den = changes[ci][1], changes[ci][2]; ci += 1
        return bar

    declared_key = normalize_key(keys[0][2]) if keys else 'C'
    scale = MAJOR_PCS.get(declared_key, MAJOR_PCS['C'])

    print('=== FILE ===')
    print(path)
    print(f'type={mid.type} tracks={len(mid.tracks)} tpb={tpb} length_sec={mid.length:.2f} notes={len(notes)}')
    print('tempos:', [(bar_of(t), round(bpm, 2)) for t, _, bpm in tempos[:120]])
    print('time_signatures:', [(bar_of(t), n, d) for t, n, d in ts])
    print('keys:', keys[:40])
    print('programs:', programs[:60])
    print('markers:', [(bar_of(t), text) for t, text in markers])

    print('\n=== TRACKS ===')
    by_track = defaultdict(list)
    for n in notes: by_track[n['track_name']].append(n)
    for ti, name, msg_count, counts in track_infos:
        ns = by_track.get(name, [])
        if ns:
            pitches = [n['note'] for n in ns]; vels = [n['vel'] for n in ns]; durs = [n['dur']/tpb for n in ns]
            print(f"{ti:02d} {name!r}: notes={len(ns)} range={nn(min(pitches))}-{nn(max(pitches))} "
                  f"avgVel={sum(vels)/len(vels):.1f} avgDurQ={sum(durs)/len(durs):.2f} msgs={msg_count}")
        else:
            print(f"{ti:02d} {name!r}: notes=0 msgs={msg_count}")

    print('\n=== GLOBAL PITCH CLASSES ===')
    pc = Counter(n['note'] % 12 for n in notes)
    outside = sum(v for k, v in pc.items() if k not in scale)
    total = sum(pc.values()) or 1
    print([(NOTE[k], v) for k, v in pc.most_common()])
    print(f'outside_{declared_key}_major={outside}/{total} ({outside/total*100:.1f}%)')

    print('\n=== SECTIONS ===')
    spans = []
    if markers:
        spans.append(('Intro', 0, markers[0][0]))
        for i, (t, text) in enumerate(markers):
            end = markers[i+1][0] if i+1 < len(markers) else max_tick
            spans.append((text, t, end))
    else:
        spans.append(('Whole file', 0, max_tick))
    for label, start, end in spans:
        ns = [n for n in notes if start <= n['start'] < end]
        pcs = Counter(n['note'] % 12 for n in ns)
        tracks = Counter(n['track_name'] for n in ns)
        out = sum(v for k, v in pcs.items() if k not in scale)
        rng = f"{nn(min(n['note'] for n in ns))}-{nn(max(n['note'] for n in ns))}" if ns else ''
        print(f"{label}: bars {bar_of(start)}-{bar_of(end)} sec={tick_to_sec(end)-tick_to_sec(start):.1f} "
              f"notes={len(ns)} range={rng} chrom%={out/max(1,len(ns))*100:.1f} "
              f"topPC={[(NOTE[k],v) for k,v in pcs.most_common(5)]} topTracks={tracks.most_common(4)}")

    print('\n=== DENSITY BY 8-BAR WINDOW ===')
    win = Counter()
    for n in notes:
        b = bar_of(n['start']); win[((b-1)//8)*8+1] += 1
    for w in sorted(win):
        print(f'bars {w:03d}-{w+7:03d}: {win[w]} notes')

    print('\n=== LARGE SIMULTANEOUS ATTACKS ===')
    attacks = defaultdict(list)
    for n in notes: attacks[n['start']].append(n)
    clusters = [(t, ns) for t, ns in attacks.items() if len(ns) >= 12]
    clusters.sort(key=lambda x: x[0])
    print('count:', len(clusters))
    for t, ns in clusters[:50]:
        print(f"bar {bar_of(t)} tick {t}: {len(ns)} notes range={nn(min(n['note'] for n in ns))}-{nn(max(n['note'] for n in ns))}")

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print(__doc__)
        raise SystemExit(2)
    main(sys.argv[1])
