#!/usr/bin/env python3
"""
Harmony vs Lead Chord-Tone Analyzer

Analyzes a MIDI file to determine what percentage of notes in each track
are chord tones vs non-chord tones, relative to a defined chord progression.

Usage:
    /usr/bin/python3 harmony_lead_check.py <midi_path> [--chords "CHORD1,CHORD2,..."] [--bar-len 4]

If --chords is omitted, the script infers a I-IV-V-I progression from key/time sigs.

Examples:
    /usr/bin/python3 harmony_lead_check.py song.mid
    /usr/bin/python3 harmony_lead_check.py song.mid --chords "A7,A7,D7,A7,D7,A7,E7,A7"
    /usr/bin/python3 harmony_lead_check.py song.mid --chords "A7,A7,D7,A7" --scale-pcs "9,0,2,3,4,7"

Pitch classes are ABSOLUTE (C=0, C#=1, ..., B=11) — NOT relative to key center.
For key-of-A analysis, A=pc9, C=pc0, D=pc2, Eb=pc3, E=pc4, G=pc7.
"""
from __future__ import annotations

import argparse
import sys
from collections import defaultdict
from pathlib import Path

import mido

NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']

# Chord pitch class definitions (absolute — C=0 through B=11)
CHORD_DICT = {
    "A":  {9, 0, 4, 7},    "Am": {9, 0, 4, 7},
    "A7": {9, 1, 4, 7},    "Am7":{9, 0, 4, 7},
    "Bb": {10, 1, 5, 8},   "Bbm":{10, 1, 5, 8},
    "B":  {11, 2, 6, 9},   "Bm": {11, 2, 6, 9},
    "C":  {0, 4, 7},       "Cm": {0, 3, 7},
    "C7": {0, 4, 7, 10},   "Cm7":{0, 3, 7, 10},
    "Db": {1, 5, 8},       "Dbm":{1, 4, 8},
    "D":  {2, 6, 9},       "Dm": {2, 5, 9},
    "D7": {2, 6, 9, 0},    "Dm7":{2, 5, 9, 0},
    "Eb": {3, 7, 10},      "Ebm":{3, 6, 10},
    "E":  {4, 8, 11},      "Em": {4, 7, 11},
    "E7": {4, 8, 11, 2},   "Em7":{4, 7, 11, 2},
    "F":  {5, 9, 0},       "Fm": {5, 8, 0},
    "F7": {5, 9, 0, 3},    "Fm7":{5, 8, 0, 3},
    "F#": {6, 10, 1},      "F#m":{6, 9, 1},
    "G":  {7, 11, 2},      "Gm": {7, 10, 2},
    "G7": {7, 11, 2, 5},   "Gm7":{7, 10, 2, 5},
    "Ab": {8, 0, 3},       "Abm":{8, 11, 3},
}


def n2n(n: int) -> str:
    """MIDI note number to note name (e.g. 60 -> C4)."""
    return f"{NOTE_NAMES[n % 12]}{n // 12 - 1}"


def parse_chord_defs(chord_str: str) -> list[set[int]]:
    """Parse comma-separated chord names into list of pitch class sets."""
    chords = []
    for name in chord_str.split(","):
        name = name.strip()
        if name in CHORD_DICT:
            chords.append(CHORD_DICT[name])
        else:
            print(f"Warning: Unknown chord '{name}', treating as empty", file=sys.stderr)
            chords.append(set())
    return chords


def auto_chords(mid: mido.MidiFile) -> list[set[int]] | None:
    """Attempt to infer a simple 8-bar I-IV-V-I progression from key signature."""
    for track in mid.tracks:
        for msg in track:
            if msg.type == 'key_signature':
                key = msg.key
                root = key.rstrip('m#b')
                is_minor = key.endswith('m')
                try:
                    root_pc = NOTE_NAMES.index(root.capitalize())
                except ValueError:
                    return None
                if is_minor:
                    I = CHORD_DICT.get(f"{root}m", set())
                    IV = CHORD_DICT.get(f"{NOTE_NAMES[(root_pc + 5) % 12]}m", set())
                    V = CHORD_DICT.get(f"{NOTE_NAMES[(root_pc + 7) % 12]}m", set())
                else:
                    I = CHORD_DICT.get(f"{root}7", CHORD_DICT.get(root, set()))
                    IV = CHORD_DICT.get(f"{NOTE_NAMES[(root_pc + 5) % 12]}7", set())
                    V = CHORD_DICT.get(f"{NOTE_NAMES[(root_pc + 7) % 12]}7", set())
                if I and IV and V:
                    return [I, I, IV, I, IV, I, V, I]
                return None
    return None


def get_tempo_bpm(mid: mido.MidiFile) -> int:
    """Get BPM from first tempo event."""
    for track in mid.tracks:
        for msg in track:
            if msg.type == 'set_tempo':
                return round(mido.tempo2bpm(msg.tempo))
    return 120


def analyze(midi_path: str, chord_list: list[set[int]], scale_pcs: set[int] | None, bar_len: int):
    """Run harmony-vs-lead analysis on MIDI file."""
    mid = mido.MidiFile(midi_path)
    tpb = mid.ticks_per_beat
    bar = tpb * bar_len
    bpm = get_tempo_bpm(mid)
    dur_sec = mid.length

    print(f"=== HARMONY vs LEAD ANALYSIS ===")
    print(f"File: {midi_path}")
    print(f"Type: {mid.type} | Tracks: {len(mid.tracks)} | TPB: {tpb}")
    print(f"BPM: {bpm} | Duration: {dur_sec:.1f}s | Bar: {bar_len}/4")
    print(f"Chords: {len(chord_list)} bars")
    if scale_pcs:
        scale_names = sorted([NOTE_NAMES[p] for p in scale_pcs])
        print(f"Scale: {scale_names} = pcs {sorted(scale_pcs)}")
    print()

    # Parse all tracks
    track_data = []
    for idx, track in enumerate(mid.tracks):
        notes = []
        abs_tick = 0
        track_name = f"Track {idx}"
        for msg in track:
            abs_tick += msg.time
            if msg.type == 'track_name':
                track_name = msg.name
            if msg.type == 'note_on' and msg.velocity > 0:
                notes.append((abs_tick, msg.note, msg.velocity, msg.channel))
        if notes:
            track_data.append((idx, track_name, notes))

    if not track_data:
        print("No note data found.")
        return

    # Per-track analysis
    for t_idx, t_name, notes in track_data:
        total = len(notes)
        chord_hits = 0
        blues_hits = 0
        miss_pcs = defaultdict(int)
        miss_context = []

        for tick, note, vel, ch in notes:
            bar_num = tick // bar
            if bar_num >= len(chord_list):
                bar_num %= len(chord_list)
            chord_pcs = chord_list[bar_num]
            pc = note % 12

            if pc in chord_pcs:
                chord_hits += 1
            else:
                miss_pcs[pc] += 1
                if len(miss_context) < 15:
                    beat = (tick % bar) / tpb
                    miss_context.append((bar_num + 1, chord_name_at(chord_list, bar_num), beat, n2n(note), pc))

                if scale_pcs and pc in scale_pcs:
                    blues_hits += 1

        ct_pct = 100.0 * chord_hits / total

        print(f"Track {t_idx:2d}: {t_name}")
        print(f"  {total:4d} notes | {chord_hits:4d} chord tones ({ct_pct:5.1f}%)")

        if scale_pcs and blues_hits:
            non_ct = total - chord_hits
            inside_scale_pct = 100.0 * blues_hits / max(non_ct, 1)
            print(f"  Of {non_ct} non-chord tones: {blues_hits} inside scale ({inside_scale_pct:.0f}%)")

        if miss_pcs:
            print(f"  Non-chord pitch classes:")
            for pc, cnt in sorted(miss_pcs.items(), key=lambda x: -x[1]):
                in_scale = "SCALE" if (scale_pcs and pc in scale_pcs) else "OUTSIDE"
                print(f"    {NOTE_NAMES[pc]:4s} (pc{pc:2d}) x{cnt:3d} [{in_scale}]")

        if miss_context:
            print(f"  Sample non-chord contexts:")
            for bar_num, cname, beat, note_name, pc in miss_context:
                print(f"    Bar {bar_num:2d} {cname:4s} beat {beat:.2f}: {note_name} (pc{pc})")
        print()

    # Per-bar breakdown for first track (assumed lead)
    lead = track_data[0][2] if track_data else []
    print("--- Per-bar breakdown (lead track) ---")
    total_bars = len(chord_list)
    for b in range(total_bars):
        chord_pcs = chord_list[b]
        notes_in_bar = [(t, n, v) for t, n, v, _ in lead if t // bar == b]
        if not notes_in_bar:
            continue
        ct = sum(1 for _, n, _ in notes_in_bar if (n % 12) in chord_pcs)
        total_in_bar = len(notes_in_bar)
        pct = 100.0 * ct / total_in_bar
        outside_pcs = sorted(set(n % 12 for _, n, _ in notes_in_bar if (n % 12) not in chord_pcs))
        outside_names = [NOTE_NAMES[p] for p in outside_pcs]
        print(f"  Bar {b+1:2d}: {ct:3d}/{total_in_bar:3d} = {pct:3.0f}% chord tones", end="")
        if outside_pcs:
            print(f"  non-CT: {outside_names}", end="")
        print()

    # Summary
    print("=== SUMMARY ===")
    for t_idx, t_name, notes in track_data:
        total = len(notes)
        chord_hits = 0
        for tick, note, vel, ch in notes:
            bar_num = tick // bar
            if bar_num >= len(chord_list):
                bar_num %= len(chord_list)
            if (note % 12) in chord_list[bar_num]:
                chord_hits += 1
        pct = 100.0 * chord_hits / total
        print(f"  {t_name}: {chord_hits}/{total} = {pct:.1f}% chord tones")
    print()

    # Cross-track conflict detection
    print("--- Cross-track conflict scan ---")
    all_notes = []
    for t_idx, t_name, notes in track_data:
        for tick, note, vel, ch in notes:
            all_notes.append((tick, note, t_idx, t_name))
    all_notes.sort()

    clashes_found = 0
    for i in range(len(all_notes)):
        for j in range(i + 1, len(all_notes)):
            if abs(all_notes[j][0] - all_notes[i][0]) > 2:
                break
            n1, n2 = all_notes[i][1], all_notes[j][1]
            interval = abs(n1 - n2) % 12
            if interval in (1, 11, 6):
                if clashes_found < 8:
                    t1_name = all_notes[i][3]
                    t2_name = all_notes[j][3]
                    tick_abs = all_notes[j][0]
                    bar_num = tick_abs // bar
                    beat = (tick_abs % bar) / tpb
                    int_name = {1: "m2", 11: "M7", 6: "TT"}[interval]
                    print(f"  {int_name} clash bar {bar_num+1} beat {beat:.2f}: {n2n(n1)} vs {n2n(n2)} ({t1_name}/{t2_name})")
                    clashes_found += 1
    if clashes_found == 0:
        print("  No harsh interval clashes detected")
    print()


def chord_name_at(chord_list: list[set[int]], idx: int) -> str:
    """Best-effort reverse lookup of chord name from pitch class set."""
    pcs = chord_list[idx]
    for name, def_pcs in CHORD_DICT.items():
        if pcs == def_pcs:
            return name
    if pcs:
        return NOTE_NAMES[sorted(pcs)[0]]
    return "???"


def main():
    parser = argparse.ArgumentParser(description="Harmony vs Lead Chord-Tone Analyzer")
    parser.add_argument("midi", type=str, help="Path to MIDI file")
    parser.add_argument("--chords", type=str, default=None,
                        help="Comma-separated chord progression (e.g. 'A7,A7,D7,A7')")
    parser.add_argument("--scale-pcs", type=str, default=None,
                        help="Comma-separated scale pitch classes for blues analysis (e.g. '9,0,2,3,4,7')")
    parser.add_argument("--bar-len", type=int, default=4,
                        help="Beats per bar (default: 4)")
    args = parser.parse_args()

    mid = mido.MidiFile(args.midi)

    if args.chords:
        chord_list = parse_chord_defs(args.chords)
    else:
        auto = auto_chords(mid)
        if auto:
            chord_list = auto
            names = [chord_name_at(auto, i) for i in range(len(auto))]
            print(f"Auto-inferred progression: {', '.join(names)}")
        else:
            print("Error: No chord progression provided and could not auto-infer.", file=sys.stderr)
            sys.exit(1)

    if args.scale_pcs:
        scale_pcs = set(int(p.strip()) for p in args.scale_pcs.split(","))
    else:
        scale_pcs = None

    analyze(args.midi, chord_list, scale_pcs, args.bar_len)


if __name__ == "__main__":
    main()