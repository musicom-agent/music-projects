import mido
import sys
from collections import Counter

def analyze_harmonics(midi_path):
    mid = mido.MidiFile(midi_path)
    events = []
    curr = 0
    for track in mid.tracks:
        for msg in track:
            curr += msg.time
            if msg.type == 'note_on' and msg.velocity > 0:
                events.append((curr, msg.note))
    
    # 8th note window (assuming 480 PPQ)
    windows = {}
    for t, n in events:
        win = t // 240
        if win not in windows: windows[win] = set()
        windows[win].add(n % 12)
        
    chords = [str(sorted(list(p))) for p in windows.values() if len(p) >= 2]
    return Counter(chords).most_common(10)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        res = analyze_harmonics(sys.argv[1])
        for c, count in res: print(f"{c}: {count}")
