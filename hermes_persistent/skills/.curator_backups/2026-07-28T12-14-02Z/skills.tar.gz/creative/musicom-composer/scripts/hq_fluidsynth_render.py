import numpy as np
import wave
import ctypes
import os

# Standard GM SoundFont path in this environment
SF2_PATH = '/usr/share/sounds/sf2/FluidR3_GM.sf2'

def hq_render(tracks, output_base, bpm=120):
    """
    Standardized HQ FluidSynth rendering.
    tracks: list of dicts {'inst': int, 'events': [{'pitch': int, 'dur': float, 'vel': int}]}
    """
    lib = ctypes.CDLL('libfluidsynth.so.3')
    
    # Signatures
    lib.new_fluid_settings.restype = ctypes.c_void_p
    lib.new_fluid_synth.argtypes = [ctypes.c_void_p]
    lib.new_fluid_synth.restype = ctypes.c_void_p
    lib.fluid_settings_setstr.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_char_p]
    lib.fluid_settings_setnum.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_double]
    lib.fluid_synth_sfload.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
    lib.fluid_synth_program_change.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    lib.fluid_synth_noteon.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_int]
    lib.fluid_synth_noteoff.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    lib.fluid_synth_write_float.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_int, ctypes.c_int, ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    lib.fluid_synth_set_reverb.argtypes = [ctypes.c_void_p, ctypes.c_double, ctypes.c_double, ctypes.c_double, ctypes.c_double]

    settings = lib.new_fluid_settings()
    lib.fluid_settings_setstr(settings, b"audio.driver", b"file")
    lib.fluid_settings_setnum(settings, b"synth.gain", 1.0)
    
    synth = lib.new_fluid_synth(settings)
    lib.fluid_synth_sfload(synth, SF2_PATH.encode(), 1)
    
    # Standard reverb for scale
    lib.fluid_synth_set_reverb(synth, 0.8, 0.5, 1.0, 0.7)
    
    sr = 44100
    total_dur = max([sum(e['dur'] for e in t['events']) for t in tracks])
    num_samples = int((total_dur + 3.0) * sr) # Reverb tail
    
    master_l = np.zeros(num_samples, dtype=np.float32)
    master_r = np.zeros(num_samples, dtype=np.float32)
    
    for ch, t in enumerate(tracks):
        lib.fluid_synth_program_change(synth, ch, t['inst'])
        curr_time = 0.0
        for e in t['events']:
            lib.fluid_synth_noteon(synth, ch, e['pitch'], e.get('vel', 100))
            dur_samples = int(e['dur'] * sr)
            bl, br = (ctypes.c_float * dur_samples)(), (ctypes.c_float * dur_samples)()
            lib.fluid_synth_write_float(synth, dur_samples, bl, 0, 1, br, 0, 1)
            
            start = int(curr_time * sr)
            master_l[start : start + dur_samples] += np.frombuffer(bl, dtype=np.float32)
            master_r[start : start + dur_samples] += np.frombuffer(br, dtype=np.float32)
            
            lib.fluid_synth_noteoff(synth, ch, e['pitch'])
            curr_time += e['dur']
            
    # Final normalization
    mono = (master_l + master_r) * 0.5
    peak = np.max(np.abs(mono))
    if peak > 0: mono = mono * (0.95 / peak)

    with wave.open(output_base + ".wav", 'w') as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(sr)
        wf.writeframes((mono * 32767).astype(np.int16).tobytes())
    
    lib.delete_fluid_synth(synth)
    lib.delete_fluid_settings(settings)
    return output_base + ".wav"
