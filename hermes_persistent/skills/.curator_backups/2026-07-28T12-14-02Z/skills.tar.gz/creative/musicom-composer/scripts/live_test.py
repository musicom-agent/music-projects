"""
Musicom Composer: Live Test — numpy-only fallback synthesis
Generates a 20s ambient jazz piece with full layering:
  - Pad, bass, chord, melody, and bell harmonics layers
  - Exports WAV + OGG (Opus for Telegram)
  - No music21/musicpy required

Usage: /opt/hermes/.venv/bin/python3 /opt/data/skills/creative/musicom-composer/scripts/live_test.py
"""

import numpy as np
import wave
import os
import subprocess

# === CONFIGURATION ===
SAMPLE_RATE = 44100
TEMPO = 80
BEAT_DURATION = 60.0 / TEMPO
CHORD_DURATION = BEAT_DURATION * 2
NOTE_DURATION = BEAT_DURATION * 0.8
GAP_MS = 50
ATTACK_MS = 10
RELEASE_MS = 80
VOLUME = 0.25

def midi_to_freq(midi):
    return 440.0 * (2.0 ** ((midi - 69) / 12.0))

C_MAJOR = {
    'C4': 60, 'D4': 62, 'E4': 64, 'F4': 65, 'G4': 67, 'A4': 69, 'B4': 71, 'C5': 72,
    'C3': 48, 'D3': 50, 'E3': 52, 'F3': 53, 'G3': 55, 'A3': 57, 'B3': 59,
}

CHORDS = {
    'C':  [60, 64, 67],
    'G':  [67, 71, 72],
    'Am': [69, 72, 76],
    'F':  [65, 69, 72],
}

PROGRESSION = ['C', 'G', 'Am', 'F']
MELODY_NOTES = [
    60, 64, 67, 72, 67, 64, 62, 60,
    62, 65, 67, 72, 71, 69, 67, 65,
    64, 67, 69, 72, 71, 69, 67, 64,
    60, 64, 67, 72, 60, 60, 72, 0,
]

def make_envelope(length, attack_s=0.01, release_s=0.05, sustain=0.7):
    env = np.ones(length) * sustain
    attack_samples = min(int(attack_s * SAMPLE_RATE), length)
    release_samples = min(int(release_s * SAMPLE_RATE), length)
    if attack_samples > 0:
        env[:attack_samples] = np.linspace(0, 1, attack_samples)
    if release_samples > 0 and length > attack_samples:
        rel_start = length - release_samples
        env[rel_start:] = np.linspace(sustain, 0, release_samples)
    return env

def generate_tone(midi_note, duration_s, gain=0.3):
    if midi_note <= 0:
        return np.zeros(int(duration_s * SAMPLE_RATE))
    freq = midi_to_freq(midi_note)
    n = int(duration_s * SAMPLE_RATE)
    t = np.linspace(0, duration_s, n, endpoint=False)
    tone = np.sin(2 * np.pi * freq * t)
    tone += 0.15 * np.sin(2 * np.pi * freq * 2 * t)
    tone += 0.05 * np.sin(2 * np.pi * freq * 3 * t)
    env = make_envelope(n, ATTACK_MS/1000, RELEASE_MS/1000)
    return tone * env * gain

def generate_chord(midi_notes, duration_s, gain=0.12):
    samples = np.zeros(int(duration_s * SAMPLE_RATE))
    for note in midi_notes:
        samples += generate_tone(note, duration_s, gain=gain)
    return samples

def generate_bass(midi_notes, duration_s, gain=0.2):
    samples = np.zeros(int(duration_s * SAMPLE_RATE))
    for note in midi_notes:
        freq = midi_to_freq(note) / 2
        n = int(duration_s * SAMPLE_RATE)
        t = np.linspace(0, duration_s, n, endpoint=False)
        tone = np.sin(2 * np.pi * freq * t) + 0.1 * np.sin(2 * np.pi * freq * 2 * t)
        env = make_envelope(n, ATTACK_MS/1000, RELEASE_MS/1000)
        samples += tone * env * gain
    return samples

def generate_pad(chord_notes, duration_s, gain=0.06):
    samples = np.zeros(int(duration_s * SAMPLE_RATE))
    for note in chord_notes:
        freq = midi_to_freq(note)
        n = int(duration_s * SAMPLE_RATE)
        t = np.linspace(0, duration_s, n, endpoint=False)
        tone = 0.5 * np.sin(2 * np.pi * freq * t) + 0.5 * np.sin(2 * np.pi * freq * 1.003 * t)
        env = make_envelope(n, 0.1, 0.2, sustain=0.6)
        samples += tone * env * gain
    return samples

def generate_harmonics(midi_note, duration_s, gain=0.04):
    if midi_note <= 0:
        return np.zeros(int(duration_s * SAMPLE_RATE))
    freq = midi_to_freq(midi_note)
    n = int(duration_s * SAMPLE_RATE)
    t = np.linspace(0, duration_s, n, endpoint=False)
    tone = (0.3 * np.sin(2 * np.pi * freq * 3 * t) +
            0.15 * np.sin(2 * np.pi * freq * 4 * t) +
            0.08 * np.sin(2 * np.pi * freq * 5 * t))
    env = make_envelope(n, 0.05, 0.5, sustain=0.3)
    return tone * env * gain

# === BUILD COMPOSITION ===
print("=" * 60)
print("🎵 COMPOSING: C Major Ambient Jazz")
print("=" * 60)
print(f"Tempo: {TEMPO} BPM | Duration: ~{len(PROGRESSION) * CHORD_DURATION:.1f}s per phrase\n")

all_audio = np.array([])
for phrase in range(2):
    print(f"📝 Phrase {phrase + 1}:")
    for i, chord_name in enumerate(PROGRESSION * (1 if phrase == 0 else 2)):
        chord_idx = (phrase * len(PROGRESSION) + i) % len(PROGRESSION)
        cname = PROGRESSION[chord_idx]
        chord_notes = CHORDS[cname]
        start_time = (phrase * len(PROGRESSION) + i) * CHORD_DURATION
        
        pad = generate_pad(chord_notes, CHORD_DURATION, gain=0.06)
        bass = generate_bass([chord_notes[0] - 12], CHORD_DURATION, gain=0.2)
        chord = generate_chord(chord_notes, CHORD_DURATION, gain=0.12)
        
        melody_note_idx = int(start_time / BEAT_DURATION) % len(MELODY_NOTES)
        melody_note = MELODY_NOTES[melody_note_idx]
        melody = generate_tone(melody_note, NOTE_DURATION, gain=0.2)
        harmonics = generate_harmonics(melody_note, NOTE_DURATION, gain=0.04) if melody_note > 0 else np.zeros_like(melody)
        
        samples = np.zeros(int(CHORD_DURATION * SAMPLE_RATE))
        melody_len = min(len(melody), len(samples))
        samples[:melody_len] += melody[:melody_len]
        harmonics_len = min(len(harmonics), len(samples))
        samples[:harmonics_len] += harmonics[:harmonics_len]
        samples += pad + bass + chord
        
        gap = np.zeros(int(GAP_MS / 1000 * SAMPLE_RATE))
        all_audio = np.concatenate([all_audio, samples, gap])
        print(f"  Chord {i+1}: {cname} | {CHORD_DURATION:.1f}s")

final_silence = np.zeros(int(2.0 * SAMPLE_RATE))
all_audio = np.concatenate([all_audio, final_silence])

# === SAVE ===
output_dir = '/tmp/hermes/songs'
os.makedirs(output_dir, exist_ok=True)
wav_path = os.path.join(output_dir, 'live_test.wav')
all_audio = np.clip(all_audio, -1.0, 1.0)
audio_int16 = (all_audio * 32767).astype(np.int16)
with wave.open(wav_path, 'w') as wf:
    wf.setnchannels(1)
    wf.setsampwidth(2)
    wf.setframerate(SAMPLE_RATE)
    wf.writeframes(audio_int16.tobytes())

print(f"\n✅ WAV: {wav_path} ({len(audio_int16) / SAMPLE_RATE:.1f}s, {os.path.getsize(wav_path)/1024:.0f} KB)")

# OGG for Telegram
ogg_path = wav_path.replace('.wav', '.ogg')
result = subprocess.run(
    ['ffmpeg', '-i', wav_path, '-codec:a', 'libopus', '-application', 'voip',
     '-b:a', '48k', ogg_path, '-y', '-loglevel', 'error'],
    capture_output=True, text=True, timeout=30
)
if os.path.exists(ogg_path):
    print(f"✅ OGG: {ogg_path} ({os.path.getsize(ogg_path)/1024:.0f} KB)")
    print(f"\n📤 Telegram: send_message to telegram:8684633270")
    print(f"   message: 'Live test! 🎵\\nMEDIA:{ogg_path}'")
else:
    print(f"\n⚠️ OGG conversion failed (ffmpeg not available)")