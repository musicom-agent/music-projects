import os
import subprocess
import shutil

SF2_PATH = "/usr/share/sounds/sf2/FluidR3_GM.sf2"

def render_all_midi(projects_root="/opt/data/projects"):
    """Finds every .mid file in projects/ and renders to high-quality OGG."""
    for root, dirs, files in os.walk(projects_root):
        if "midi" in root:
            audio_dir = root.replace("/midi", "/audio")
            os.makedirs(audio_dir, exist_ok=True)
            
            for f in files:
                if f.endswith((".mid", ".midi")):
                    midi_path = os.path.join(root, f)
                    base_name = os.path.splitext(f)[0]
                    wav_path = os.path.join(audio_dir, f"{base_name}_native.wav")
                    ogg_path = os.path.join(audio_dir, f"{base_name}_native.ogg")
                    
                    print(f"Rendering: {midi_path}")
                    # CLI render
                    subprocess.run(["fluidsynth", "-ni", SF2_PATH, midi_path, "-F", wav_path, "-r", "44100"], check=False)
                    # Convert to OGG Opus
                    subprocess.run(["ffmpeg", "-i", wav_path, "-codec:a", "libopus", "-b:a", "128k", ogg_path, "-y", "-loglevel", "error"], check=False)
                    
                    if os.path.exists(wav_path):
                        os.remove(wav_path)

if __name__ == "__main__":
    render_all_midi()
