import pretty_midi
import soundfile as sf
import subprocess
import os
import sys

def render_and_send(midi_path, ogg_path):
    """Standard Musicom render pipeline: MIDI -> OGG Opus"""
    wav_path = ogg_path.replace(".ogg", ".wav")
    pm = pretty_midi.PrettyMIDI(midi_path)
    audio = pm.synthesize(fs=44100)
    sf.write(wav_path, audio, 44100)
    subprocess.run([
        "ffmpeg", "-i", wav_path, "-codec:a", "libopus", "-application", "voip", 
        "-b:a", "48k", ogg_path, "-y", "-loglevel", "error"
    ], check=True)
    print(f"MEDIA:{ogg_path}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 render_and_send.py <midi_path> <ogg_path>")
    else:
        render_and_send(sys.argv[1], sys.argv[2])
