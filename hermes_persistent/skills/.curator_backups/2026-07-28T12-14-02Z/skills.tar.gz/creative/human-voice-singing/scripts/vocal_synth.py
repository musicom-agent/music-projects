import numpy as np
import wave
from scipy import signal

SAMPLE_RATE = 44100

def generate_vowel(frequency, duration, vowel='A', vibrato_freq=5.5, vibrato_depth=0.012):
    t = np.linspace(0, duration, int(SAMPLE_RATE * duration), False)
    
    # Vibrato (FM)
    vibrato = 1 + vibrato_depth * np.sin(2 * np.pi * vibrato_freq * t)
    
    # Glottal source (Pulse train / Buzz)
    buzz = signal.sawtooth(2 * np.pi * frequency * vibrato * t)
    
    # Formants (F1, F2, F3) for common vowels
    # [F1, F2, F3]
    vowel_map = {
        'A': [730, 1090, 2440],
        'E': [270, 2290, 3010],
        'I': [270, 2290, 3010],
        'O': [570, 840, 2410],
        'U': [300, 870, 2240]
    }
    
    f1, f2, f3 = vowel_map.get(vowel, [500, 1500, 2500])
    
    # Resonant Band-pass Filters (Formants)
    def bandpass(data, lowcut, highcut, fs, order=2):
        nyq = 0.5 * fs
        low = lowcut / nyq
        high = highcut / nyq
        b, a = signal.butter(order, [low, high], btype='band')
        return signal.lfilter(b, a, data)

    # Simplified resonant peak via SciPy iirpeak
    processed = np.zeros_like(buzz)
    for f in [f1, f2, f3]:
        b, a = signal.iirpeak(f, 10, SAMPLE_RATE) # Q=10 for narrow formants
        processed += signal.lfilter(b, a, buzz)
        
    # Envelope
    env = np.ones_like(processed)
    attack = int(0.1 * SAMPLE_RATE)
    env[:attack] = np.linspace(0, 1, attack)
    env[-attack:] = np.linspace(1, 0, attack)
    
    return processed * env * 0.2

def save_vocal(filename, samples):
    with wave.open(filename, 'w') as wf:
        wf.setnchannels(1); wf.setsampwidth(2); wf.setframerate(SAMPLE_RATE)
        wf.writeframes((np.clip(samples, -1, 1) * 32767).astype(np.int16).tobytes())
